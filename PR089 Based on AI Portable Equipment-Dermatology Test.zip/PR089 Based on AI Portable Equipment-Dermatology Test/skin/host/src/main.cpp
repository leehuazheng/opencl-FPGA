#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <assert.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include "CL/opencl.h"
#include "AOCLUtils/aocl_utils.h"
//�궨��
#define STRING_BUFFER_LEN 1024 //�ַ�������������
#define weight_max_size 9472
#define input_max_size 127008
#define mid_max_size 127008
#define out_max_size 63504

#define conv_layer 16  //�ܹ��ж��ٲ�
#define MAX_SOURCE_SIZE (0x100000)//�����Դ��С
#define image_size 49152

using namespace aocl_utils;
using namespace std;

//extern options opt;
//cl_ushort *host_input;
//cl_uint *host_output;

static	float  *weight, *w1, *w2, *w3, *w4, *w5, *w6, *w7, *w8, *w9, *w10, *w11, *w12, *w13, *w14, *w15, *w16; //����ָ�룬�洢����

static cl_int status;
// OpenCL runtime configuration
static cl_platform_id platform = NULL;
static cl_device_id device = NULL;
static cl_context context = NULL;
static cl_command_queue queue = NULL;
static cl_kernel kernel = NULL;  //ע��kernel
static cl_program program = NULL;


static cl_mem buf_image_input, buf_weight, img_mid, img_out;//���建����

static unsigned int width;
static unsigned int height;


FILE *fp;//ָ�룬���ļ��õ�
char *kernel_src_str;//ָ�룬kernel��
size_t kernel_code_size;//�޷������ͣ�kernel�Ĵ����С

char *path[] = { "w1.txt","w2.txt" ,"w3.txt","w4.txt","w5.txt","w6.txt","w7.txt" ,"w8.txt","w9.txt" ,"w10.txt","w11.txt","w12.txt","w13.txt","w14.txt","w15.txt","w16.txt" };//��ȡȨ���ļ�
char *gory[] = { "MEL","NV","BCC","AKIEC","BKL","DF","VASC","normal" };
unsigned num_devices = 0;

static int Ci, Co, Wi, Wo, k, s, pad, Cmid;

static float *output;


static int category;

int main()
{
	init_opencl();
	Mat src;
	Mat BGR_frame;
	Mat resize_image_test;
	Mat resize_image_show;
	float image[3 * 128 * 128];
	int index = 0;
	char str[100];

	VideoCapture *cap = new VideoCapture(0);
	if (!cap->isOpened()) {
		return -1;
	}
	solve_problem();
	namedWindow("Skin disease detection");

	while (1)
	{
		//-- bail out if escape was pressed �ո��
		int c = waitKey(10);
		if ((char)c == 32)
		{
			if (!cap->read(src))
				return -1;

			//format conversion
			cvtColor(src, BGR_frame, CV_YUV2BGR);

			//resize image
			resize(BGR_frame, resize_image_test, Size(128, 128));
			resize(src, resize_image_show, Size(500, 500));

			//extract pixels and normalize
			index = 0;
			for (int i = 0; i < 128; i++)
			{
				for (int j = 0; j < 128; j++)
				{
					image[index] = (float)(resize_image_test.at<Vec3b>(i, j)[2]) / 255;
					image[index + 128 * 128] = (float)(resize_image_test.at<Vec3b>(i, j)[1]) / 255;
					image[index + 2 * 128 * 128] = (float)(resize_image_test.at<Vec3b>(i, j)[0]) / 255;
					//printf("R: %.3f, G: %.3f, B: %.3f\n", image[index], image[index+224*224], image[index+2*224*224]);
					index++;
				}
			}
			//��������

			run(image);
			
			sprintf(gory[category], "%s", "The detection result is:");
			putText(resize_image_show, str, Point(20, 40), FONT_HERSHEY_DUPLEX, 1,
				Scalar(0, 255, 0));

			imshow("Skin disease detection", resize_image_show);
		}
		//ESC��
		if ((char)c == 27)
		{
			cleanup();
			break;
		}
	}
	delete cap;
	destroyAllWindows();

	return 0;
}

void ReadFloat(char *filename, float *data);//��ȡ����
void solve_problem();//��ʼ������,׼������
void run(float *image);//���к���
void cleanup();//�����ռ��ڴ�
bool init_opencl();
void printdata3D(const char *s, float data_vecs[], int h, int w, int k);
int  result_out(float data_vecs[], int h, int w, int k);

bool init_opencl() {


	//width = opt.width; //��ȡ��������ͼ��Ĵ�С������û���ã������ֱ��resize
	//height = opt.height;

	if (!setCwdToExeDir()) {
		return false;
	}

	platform = findPlatform("Intel");
	if (platform == NULL) {
		printf("ERROR: Unable to find IntelFPGA OpenCL platform.\n");
		return false;
	}

	// User-visible output - Platform information ƽ̨����Ϣ
	char char_buffer[STRING_BUFFER_LEN];
	printf("Querying platform for info:\n");
	printf("==========================\n");
	clGetPlatformInfo(platform, CL_PLATFORM_NAME, STRING_BUFFER_LEN, char_buffer, NULL);
	printf("%-40s = %s\n", "CL_PLATFORM_NAME", char_buffer);
	clGetPlatformInfo(platform, CL_PLATFORM_VENDOR, STRING_BUFFER_LEN, char_buffer, NULL);
	printf("%-40s = %s\n", "CL_PLATFORM_VENDOR ", char_buffer);
	clGetPlatformInfo(platform, CL_PLATFORM_VERSION, STRING_BUFFER_LEN, char_buffer, NULL);
	printf("%-40s = %s\n\n", "CL_PLATFORM_VERSION ", char_buffer);

	// Query the available OpenCL devices. ��ѯopencl�豸
	scoped_array<cl_device_id> devices;
	cl_uint num_devices;

	devices.reset(getDevices(platform, CL_DEVICE_TYPE_ALL, &num_devices));

	// We'll just use the first device.��ѡ�õ�һ��device
	device = devices[0];

	// Create the context. ����context
	context = clCreateContext(NULL, 1, &device, NULL, NULL, &status);
	checkError(status, "Failed to create context");

	// Create the command queue.����queue
	queue = clCreateCommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, &status);
	checkError(status, "Failed to create command queue");

	// Create the program.����program
	std::string binary_file = getBoardBinaryFile("camera_sobel", device);
	printf("Using AOCX: %s\n", binary_file.c_str());
	program = createProgramFromBinary(context, binary_file.c_str(), &device, 1);

	// Build the program that was just created.����program
	status = clBuildProgram(program, 0, NULL, "", NULL, NULL);
	checkError(status, "Failed to build program");


	//host_input = (cl_ushort*)alignedMalloc(width*height * sizeof(unsigned short));

	return true;
}

void solve_problem()
{ //��Ȩ������ȫ����ȡ����
	if (num_devices == 0)
	{
		checkError(-1, "No devices");
	}

	//��ͼƬ��Ȩ�ض�ȡ��host
	//���꣬alignedFree�ͷ�
	//image = (float *)alignedMalloc(sizeof(cl_float) * image_size);
	weight = (float *)alignedMalloc(sizeof(cl_float) * weight_max_size);
	//��ȡhost_inpput�ļ�


	const char *kernel_name = "channel_depth_separable_Conv";
	kernel = clCreateKernel(program, kernel_name, &status);
	checkError(status, "Failed to create kernel");



	kernel = clCreateKernel(program, kernel_name, &status);
	checkError(status, "Failed to create kernel1");

	//�������ռ�
	buf_image_input = clCreateBuffer(context, CL_MEM_READ_ONLY, input_max_size * sizeof(cl_float), NULL, &status);
	checkError(status, "Failed to create buffer for input image");
	buf_weight = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(cl_float) * weight_max_size, NULL, &status);
	checkError(status, "Failed to create buffer for weight");
	img_mid = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(cl_float) * mid_max_size, NULL, &status);
	checkError(status, "Failed to create buffer for output");
	img_out = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(cl_float) * out_max_size, NULL, &status);
	checkError(status, "Failed to create buffer for output");

	//���ýӿڣ����Ϊ�����ͽ��д�����
	status = clSetKernelArg(kernel, 0, sizeof(cl_mem), (void*)&buf_image_input);
	checkError(status, "Failed to set argument");
	status = clSetKernelArg(kernel, 3, sizeof(cl_mem), (void*)&buf_weight);
	checkError(status, "Failed to set argument");
	status = clSetKernelArg(kernel, 5, sizeof(cl_mem), (void*)&img_mid);
	checkError(status, "Failed to set argument");
	status = clSetKernelArg(kernel, 9, sizeof(cl_mem), (void*)&img_out);
	checkError(status, "Failed to set argument");

	const double startTime = getCurrentTimestamp();

	


	
}

void run(float *image)
{
	




	const double start_time = getCurrentTimestamp();

	cl_event event_kernel;
	cl_event conv_event;

	//��imageָ���е�����д���豸ָ��buf_image_input����Ҫ�����Ĵ�����
	status = clEnqueueWriteBuffer(queue, buf_image_input, CL_TRUE, 0, image_size * sizeof(cl_float), image, 0, NULL, &conv_event);
	checkError(status, "Failed to transfer input A");
	clFinish(queue);


	//�����ֲ������Խ��к궨��
	int data[][7] = { 
	{3,16,128,63,2,1,7}, 
	{16,32,65,63,1,0,1}, 
	{32,16,65,63,1,2,1}, 
	{16,32,63,31,2,1,7}, 
	{32,64,33,31,1,0,1}, 
	{64,32,33,31,1,2,1}, 
	{32,64,33,31,1,0,1}, 
	{64,32,33,31,1,2,1}, 
	{32,64,31,15,2,1,2}, 
	{64,128,17,15,1,0,1}, 
	{128,64,17,15,1,2,1}, 
	{64,128,17,15,1,0,1}, 
	{128,64,17,15,1,2,1}, 
	{64,7,15,7,2,1,4}, 
	{7,64,9,7,1,0,1}, 
	{64,7,9,7,1,2,1} };
	//int weight_size[] = {};
	static const size_t GSize[][2] = { {63,63},{63,63},{63,63},{31,31},{31,31},{31,31},{31,31},{31,31},{15,15},{15,15},{15,15},{15,15},{15,15},{7,7},{7,7},{7,7} };
	static const size_t WSize[][2] = { {63,63},{63,63},{63,63},{31,31},{31,31},{31,31},{31,31},{31,31},{15,15},{15,15},{15,15},{15,15},{15,15},{7,7},{7,7},{7,7} };
	int weight_num[16] = { 528, 672, 832, 4608, 2368, 2688, 2368, 2688, 4704, 8832, 9472, 8832, 9472, 4160, 518, 1088 }
	//����ѭ������
	for (int loop = 0; loop < conv_layer; loop++)
	{//��ȡȨ�ز�������ζ�ȡ
		ReadFloat(path[loop], weight); //Ȩ�صĶ�ȡ������һ�ζ���
		//printf("��%d��", loop);
		//printdata3Dsep("����Ȩ��\n", weight, 3, 3, data[loop][0], data[loop][1]);//12�У�12��

		//������д��ȥ�����Բ���weight_max_size
		status = clEnqueueWriteBuffer(queue, buf_weight, CL_TRUE, 0, sizeof(cl_float)*weight_num[loop], weight, 0, NULL, &conv_event);
		checkError(status, "Failed to transfer input image");
		clWaitForEvents(1, &conv_event);
		clFinish(queue);

		Ci = data[loop][0];
		Co = data[loop][1];
		Wi = data[loop][2];
		Wo = data[loop][3];
		k = data[loop][4];
		s = data[loop][4];
		pad = data[loop][5];
		Cmid = data[loop][6];

		//����Ҫ�Ĳ������ݸ��豸
		status = clSetKernelArg(kernel, 1, sizeof(cl_int), (void*)&Wi);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 2, sizeof(cl_int), (void*)&Ci);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 4, sizeof(cl_int), (void*)&s);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 6, sizeof(cl_int), (void*)&Wo);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 7, sizeof(cl_int), (void*)&Co);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 8, sizeof(cl_int), (void*)&pad);
		checkError(status, "Failed to set argument");
		status = clSetKernelArg(kernel, 10, sizeof(cl_int), (void*)&Cmid);
		checkError(status, "Failed to set argument");
		status = clEnqueueNDRangeKernel(queue, kernel, 2, 0, GSize[loop], WSize[loop], 0, NULL, &event_kernel);
		checkError(status, "Failed to launch kernel1");

		clWaitForEvents(1, &event_kernel);//�ȴ�ִ�н�����������ִ�е�ʱ��
		if (loop == conv_layer - 1)
		{
			output = (float *)alignedMalloc(sizeof(cl_float) * Wo*Wo*Co);
			status = clEnqueueReadBuffer(queue, buf_image_input, CL_TRUE, 0, sizeof(cl_float) * Wo*Wo*Co, output, 0, NULL, NULL);
			checkError(status, "Failed to map output");
			category = result_out(output, Wo, Wo, Co);

		}
		clReleaseEvent(conv_event);
	}
	
	const double end_time = getCurrentTimestamp();//ʱ�亯��


	printf("\nTime: %0.3f ms\n", (end_time - start_time) * 1e3);



	cl_ulong time_ns = getStartEndTime(event_kernel);//�鿴�¼���ʱ��
	printf("Kernel time : %0.3f ms\n", double(time_ns) * 1e-6);


	clReleaseEvent(event_kernel);
	printf("\n");

}
// Free the resources allocated during initialization
void cleanup() {
	// Free the resources allocated
	if (buf_image_input != NULL) {
		clReleaseMemObject(buf_image_input);
	}
	if (buf_weight != NULL) {
		clReleaseMemObject(buf_weight);
	}
	if (img_mid != NULL) {
		clReleaseMemObject(img_mid);
	}
	if (img_out != NULL) {
		clReleaseMemObject(img_out);
	}

	if (kernel) {
		clReleaseKernel(kernel);
	}
	if (program) {
		clReleaseProgram(program);
	}
	if (queue) {
		clReleaseCommandQueue(queue);
	}
	if (context) {
		clReleaseContext(context);
	}
}

void ReadFloat(char *filename, float *data)
{
	FILE *fp = fopen(filename, "r");					//�����ļ���ָ�룬���ڴ򿪶�ȡ���ļ�
	printf("%p\n", fp);
	//fp1 = fopen(filename, "r+");	//��д��ʽ���ļ�
	if (fp == NULL)
	{
		printf("��ʧ��\n");
		perror("fail to read");
		//exit(1);
	}//�����ļ���ָ�룬���ڴ򿪶�ȡ���ļ�
	printf("���ļ�\n");
	int j = 0;
	while (fscanf(fp, "%f", &data[j++]) != -1);//���ж�ȡfp1��ָ���ļ��е����ݵ�data��

	//fclose(fp1);				//�ر��ļ����д򿪾�Ҫ�йر�
}

void printdata3D(const char *s, float data_vecs[], int h, int w, int k)
{
	printf(s);
	for (int m = 0; m < k; m++)
	{
		printf("page:%d\n", m);
		for (int i = 0; i < h; i++) {
			if (i < 10)
				printf("row[0%d]:", i);

			else  printf("row[%d]:", i);
			for (int j = 0; j < w; j++) {
				printf("%12.6f,", data_vecs[m*h*w + i * w + j]);
			}
			printf("\n");
		}
		printf("\n");
	}

}

int  result_out(float data_vecs[], int h, int w, int k)//���볤����channel
{	//�ȼ�����
	//�ڱȽ�7�����ֵĴ�С
	//��󷵻ط��صĽ��

	char *data[8] = { "MEL","NV","BCC","AKIEC","BKL","DF","VASC","normal" };
	float result = 0.0;
	float max = 0.0;
	int num = 0;
	for (int m = 0; m < k; m++)
	{
		result = 0.0;
		for (int i = 0; i < h*w; i++)
		{
			result += data_vecs[k*h*w + i];

		}
		result = 1 / (1 + exp(-result));
		if (max < result)
		{
			max = result;
			num = m;
		}
	}
	if (max < 0.8)
	{
		num = 7;
	}
	printf("category:%s", data[num]);
	return num;

}
//����ת������
