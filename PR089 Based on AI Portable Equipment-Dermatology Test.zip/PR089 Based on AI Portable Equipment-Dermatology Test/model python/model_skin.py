""""
1:依照resnet来进行模块化实现
2：实现数据增强
3：保存模型
4：读取模型的权重，并进行转换浮点的移植
5：进行移植
"""
import keras
import numpy as np
import os
import h5py
from keras.callbacks import TensorBoard

from keras.callbacks import ModelCheckpoint
import hdf5datasetgenerator as HDF
from keras.preprocessing.image import ImageDataGenerator #对数据进行分批读取，数据增强
from keras.models import Sequential
from keras.layers import Input,BatchNormalization
from keras.models import Model
from keras.layers import SeparableConv2D,DepthwiseConv2D,AveragePooling2D,GlobalAveragePooling2D,Conv2D,Dense #深度可分离卷积和空间卷积
from keras.layers import Dropout,Activation
from keras.callbacks import ModelCheckpoint #用于保存最好的模型
from keras.constraints import min_max_norm
from keras.layers.convolutional import ZeroPadding2D #填充0的方式
#超参数
import time
import re
import tensorflow as tf
from keras.backend.tensorflow_backend import set_session
from scipy import signal
# warnings.filterwarnings('ignore')
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.15
set_session(tf.Session(config=config))
def lr_schedule(epoch):
    """Learning Rate Schedule

    Learning rate is scheduled to be reduced after 80, 120, 160, 180 epochs.
    Called automatically every epoch as part of callbacks during training.

    # Arguments
        epoch (int): The number of epochs

    # Returns
        lr (float32): learning rate
    """
    lr = 1e-3
    if epoch > 180:
        lr *= 0.5e-3
    elif epoch > 160:
        lr *= 1e-3
    elif epoch > 120:
        lr *= 1e-2
    elif epoch > 80:
        lr *= 1e-1
    print('Learning rate: ', lr)
    return lr
def block_layer(input,filters_in,da_filters,padding,strides,dropout_ratio):#输入，原来通道个数，dropout概率
    #通道权重卷积
    channel_weight_x_1=DepthwiseConv2D(kernel_size=[1,1],strides=1,padding='valid',depth_multiplier=1,activation=None,use_bias=False,
                         kernel_constraint=min_max_norm(min_value=0, max_value=1.0))(input)
    Dro_x = Dropout(dropout_ratio)(channel_weight_x_1)
    # 3X3的分离卷积
    # sep_x = DepthwiseConv2D(kernel_size=[3, 3], strides=strides, padding=padding, depth_multiplier=1,
    #                         activation='relu', use_bias=False)(Dro_x)
    #1X1的混合通道卷积，升级通道
    add_channel_x=Conv2D(filters=da_filters,kernel_size=[1,1],strides=1,padding='valid',use_bias=False,activation='relu')(Dro_x)
    #通道权重卷积
    channel_weight_x_2 = DepthwiseConv2D(kernel_size=[1, 1], strides=1, padding='valid', depth_multiplier=1,
                                       activation=None, use_bias=False,
                                       kernel_constraint=min_max_norm(min_value=0, max_value=1.0))(add_channel_x)
    Dro_x = Dropout(dropout_ratio)(channel_weight_x_2)
    #3X3的分离卷积
    sep_x = DepthwiseConv2D(kernel_size=[3, 3], strides=strides, padding=padding, depth_multiplier=1,
                                       activation='relu', use_bias=False)(Dro_x)
    #通道权重卷积
    # channel_weight_x_3 = DepthwiseConv2D(kernel_size=[1, 1], strides=1, padding='valid', depth_multiplier=1,
    #                                    activation=None, use_bias=False,
    #                                    kernel_constraint=min_max_norm(min_value=0, max_value=1.0))(sep_x)
    # Dro_x = Dropout(dropout_ratio)(channel_weight_x_3)
    # 1X1的混合通道卷积，降通道
    de_channel_x = Conv2D(filters=filters_in, kernel_size=[1, 1], strides=1, padding='valid', use_bias=False,
                           activation='relu')(Dro_x)
    #res链接
    if padding=='same':
        s = keras.layers.add([input, de_channel_x])  #
        output = Activation('relu')(s)
        return output
    else: return de_channel_x


def block(input,filters1,strides1,strides2,filters2,dropout_ratio1,dropout_ratio2,pool_size,pool_strides):
     Blo_x1=block_layer(input,filters1,strides1,dropout_ratio1)
     # print('Blo_x1.shape:',Blo_x1.shape)
     Blo_x2=block_layer(Blo_x1, filters2, strides2, dropout_ratio2)
     # print('Blo_x2.shape:',Blo_x2.shape)
     Ave_x =AveragePooling2D(pool_size=(pool_size, pool_size), strides=pool_strides,padding='valid')(input)
     # print('Ave_x.shape:',Ave_x.shape)
     #进行分组卷积，将通道调回至原来的大小
     s=keras.layers.add([Ave_x,Blo_x2]) #
     output=Activation('relu')(s)
     return output
def bl_layer(image_in,s,Co,pad,Cmid=1,activation=None,dropout_ratio=0.1):#输入，原来通道个数，dropout概率
    #通道权重卷积
    channel_weight_x_1 = DepthwiseConv2D(kernel_size=[1, 1], strides=1, padding='valid', depth_multiplier=1,
                                         activation=None, use_bias=False,kernel_initializer='Orthogonal')(image_in)
    Dro_x = Dropout(dropout_ratio)(channel_weight_x_1)
    # 3X3的分离卷积
    if pad==0:
        pad="same"
        activation = None
    if pad==1:
        pad = "valid"
        activation='sigmoid'
    if pad==2:
        pad="same"
        activation = None
    sep_x = DepthwiseConv2D(kernel_size=[3, 3], strides=s, padding=pad, depth_multiplier=Cmid, activation=activation,
                            use_bias=False,kernel_initializer='glorot_normal')(Dro_x)
    # output_1 = Dropout(dropout_ratio)(sep_x)
    if pad==2 or  pad== 0:
        add1=keras.layers.add([image_in,sep_x])
        sep_x=Activation('sigmoid')(add1)


    #1x1卷积
    channel_1x1 = Conv2D(filters=Co, kernel_size=[1, 1], strides=1, padding='valid', use_bias=False,
                          activation='sigmoid',kernel_initializer='glorot_normal')(sep_x)
    # Dro_x = Dropout(dropout_ratio)(channel_1x1)

    # 1X1的混合通道卷积，降通道

    return channel_1x1


def network(input_shape):
    inputs = Input(shape=input_shape)
    #降低特征图大小，升高特征图的维度,并保存输出的x1
    x1=bl_layer(image_in=inputs,s=2,Co=16,pad=1,Cmid=7)
    #进行resnet
    x2 = bl_layer(image_in=x1, s=1, Co=32, pad=0, Cmid=1)
    x3= bl_layer(image_in=x2, s=1, Co=16, pad=2, Cmid=1)
    x=keras.layers.add([x1,x3])
    # #
    x1 = bl_layer(image_in=x, s=2, Co=32, pad=1, Cmid=7)
    # # # 进行resnet
    x2 = bl_layer(image_in=x1, s=1, Co=64, pad=0, Cmid=1)
    x3 = bl_layer(image_in=x2, s=1, Co=32, pad=2, Cmid=1)
    x = keras.layers.add([x1, x3])
    # #
    # x1 = bl_layer(image_in=x, s=2, Co=32, pad=1, Cmid=4, dropout_ratio=0.5)
    x2 = bl_layer(image_in=x, s=1, Co=64, pad=0, Cmid=1)
    x3 = bl_layer(image_in=x2, s=1, Co=32, pad=2, Cmid=1)
    x = keras.layers.add([x, x3])
    # #
    x1 = bl_layer(image_in=x, s=2, Co=64, pad=1, Cmid=2)
    x2 = bl_layer(image_in=x1, s=1, Co=128, pad=0, Cmid=1)
    x3 = bl_layer(image_in=x2, s=1, Co=64, pad=2, Cmid=1)
    x = keras.layers.add([x1, x3])
    # #
    # x1 = bl_layer(image_in=x, s=2, Co=16, pad=1, Cmid=4, dropout_ratio=0.5)
    x2 = bl_layer(image_in=x, s=1, Co=128, pad=0, Cmid=1)
    x3 = bl_layer(image_in=x2, s=1, Co=64, pad=2, Cmid=1)
    x = keras.layers.add([x1, x3])
    #
    x1 = bl_layer(image_in=x, s=2, Co=7, pad=1, Cmid=4)
    x2 = bl_layer(image_in=x1, s=1, Co=64, pad=0, Cmid=1)
    x3 = bl_layer(image_in=x2, s=1, Co=7, pad=2, Cmid=1)
    x = keras.layers.add([x1, x3])
    x = GlobalAveragePooling2D()(x)

    x=Activation('sigmoid')(x)
    model = Model(inputs=inputs, outputs=x)
    return model



if __name__=='__main__':
    batch_size = 4
    num_classes = 7
    epochs = 10
    inputshape=(128,128,3)



    datagen = ImageDataGenerator(
        # zca_epsilon=1e-06,  # epsilon for ZCA whitening
        rotation_range=120,  # randomly rotate images in the range (degrees, 0 to 180)
        width_shift_range=0.1,
        height_shift_range=0.1,
        channel_shift_range=8,  # set range for random channel shifts
        horizontal_flip=True,  # randomly flip images
        vertical_flip=True)

    trainGen = HDF.HDF5DatasetGenerator(dbPath='skin_trainset.hdf5', batchSize=batch_size, aug=datagen)
    # valGen = HDF.HDF5DatasetGenerator(dbPath='skin_valset.hdf5',batchSize=batch_size,aug=datagen)

    model=network(input_shape=inputshape)
    model.summary()
    #优化器
    opt = keras.optimizers.RMSprop(0.001, 1e-6)
    sgd=keras.optimizers.SGD(lr=0.00000001, decay=1e-6, momentum=0.9, nesterov=True)
    adam=keras.optimizers.Adam(lr=0.1)

    model.compile(loss='categorical_crossentropy',
                  optimizer=keras.optimizers.Adadelta,
                  metrics=['accuracy'])


    # print()
    #文件保存
    filepath = time.strftime('%Y.%m.%d %H:%M:%S ', time.localtime(time.time()))
    filepath = re.findall(r"\d*", filepath)
    filepath = [i for i in filepath if i != '']
    filepath   = '_'.join(filepath)+"_best.hdf5"
    # filepath = "weight11.best.hdf5"
    checkpoint = ModelCheckpoint(filepath, monitor='acc', verbose=1, save_best_only=True,
                                 mode='max')

    earlystopping = keras.callbacks.EarlyStopping(
        monitor='loss',  # 监视器为准确率
        patience=12,  # 当超过一个周期不动的时候就就停止训练 2 epochs
        verbose=1)
    # ReduceLROnPlateau 使用衰减学习率
    reducelornplateau = keras.callbacks.ReduceLROnPlateau(
        monitor='loss',  # 交叉验证损失函数
        factor=0.618,  # 当减少是触发，学习率变为原来的0.1
        patience=3,  # 至少10epochs不变才会减少
        mode='min',
        cooldown=0,
        # min_lr=0,
        verbose=1
    )

    # tensorboard显示模型
    tensorboard = keras.callbacks.TensorBoard(
        log_dir='log',  # 想要保存的文件夹
        histogram_freq=0,  # 按照何等频率（epoch）来计算直方图，0为不计算
        #               batch_size=32,     # 用多大量的数据计算直方图
        write_graph=True,  # 是否存储网络结构图
        write_grads=True,  # 是否可视化梯度直方图
        write_images=True,  # 是否可视化参数
        embeddings_freq=0,
        embeddings_layer_names=None,
        embeddings_metadata=None)

    callback_list = [earlystopping, reducelornplateau, tensorboard, checkpoint]
    # callback_list=[checkpoint]
    model.fit_generator(
        trainGen.generator(),
        steps_per_epoch=trainGen.numImages // batch_size,
        # validation_data=valGen.generator(),
        # validation_steps=valGen.numImages // batch_size,
        epochs=epochs,
        # max_queue_size=128 * 2,
        callbacks=callback_list,
        verbose=1
        )


    f = h5py.File('skin_test.hdf5', 'r')
    x_test=f['train_image'][:]
    y_test=f['train_labels'][:]
    loss,accuracy=model.evaluate(x_test,y_test,verbose=1)

    print('\ntest_loss:',loss,'\ntest_accuracy',accuracy)

    f = h5py.File('skin_train.hdf5', 'r')
    x_test = f['train_image'][:]
    y_test = f['train_labels'][:]
    loss, accuracy = model.evaluate(x_test, y_test, verbose=1)

    print('\ntrain_loss:', loss, '\ntrain_accuracy', accuracy)
